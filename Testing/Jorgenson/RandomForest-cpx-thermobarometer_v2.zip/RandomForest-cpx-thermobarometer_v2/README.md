# RandomForest-cpx-thermobarometer

Hey there! Thanks for coming here! This is the the Jorgenson-Higgins Random-Forest cpx thermobarometer. 

Here you'll find two zip folders which you can download for your thermobarometer needs. Both of these use R so we recommend that you are familar with R first!

1) Choose your own adventure: the full code with several scripts that allow you to see the root of whats happening and adjust things as you see fit.
2) Plug and play: a single code with premade models.

Both versions have instructions. If something isn't working for you then please let us know (corin.jorgenson@unige.ch).

Cheers!
Corin
