[![PyPI](https://badgen.net/pypi/v/Thermobar)](https://pypi.org/project/Thermobar/)
[![Build Status](https://github.com/PennyWieser/Thermobar/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/PennyWieser/Thermobar/actions/workflows/main.yml)
[![codecov](https://codecov.io/gh/PennyWieser/Thermobar/branch/main/graph/badge.svg)](https://codecov.io/gh/PennyWieser/Thermobar/branch/main)

A python tool for thermobarometry.
Examples and documentation available at
https://thermobar.readthedocs.io/en/latest/index.html
Still a work in progress, contact Penny Wieser with questions.